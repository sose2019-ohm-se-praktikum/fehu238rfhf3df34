﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MFE
{
    interface IMusicVolumeEvener
    {
        // TODO add method(s) here
    }
}
