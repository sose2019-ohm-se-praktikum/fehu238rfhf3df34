## SoSe 2019 Praktikum
